# MedShift — Product Requirements & Progress

## Original Problem Statement
Build MedShift, a production-ready healthcare staffing marketplace connecting hospitals
with verified doctors for short-term, hourly and emergency clinical shifts (launch market:
Hyderabad). Three roles — Doctor, Hospital, Admin. Core differentiator: real-time
Emergency "Need Doctor Now" instant matching, plus automatic replacement, attendance,
earnings and verification workflows.

## User Choices (v1)
- Single Expo app with **role switch at login** (Doctor / Hospital / Admin)
- **Mobile OTP** login (demo mode: dev_otp returned on-screen & auto-filled)
- Aha moment: **Emergency "Need Doctor Now"**
- Follow spec styling (deep navy + medical blue, Manrope/Inter)
- Basic admin included

## Architecture
- **Backend**: FastAPI + MongoDB (motor async), JWT auth (HS256, 30d), role-based access
  control. Routes under `/api`. Collections: users, doctors, hospitals, duties, otps,
  notifications. Matching engine scores doctors on specialty, verification, experience,
  rate, emergency-readiness, reliability, distance (haversine).
- **Frontend**: Expo Router (file-based), react-query for all server state, secure token
  storage, react-native-keyboard-controller, reanimated (pulse + swipe-to-accept),
  expo-camera (QR check-in), expo-location (geofence), Manrope/Inter via expo-font,
  MDI icons. Theme tokens in `src/theme.ts`.

## Personas
- **Doctor**: wants legitimate, well-paid duties that fit free time, fast accept + check-in.
- **Hospital ops**: needs to fill a shift now, especially emergencies, without phone calls.
- **Admin**: verifies doctors/hospitals, monitors marketplace + revenue.

## Implemented (2026-09-12)
- Auth: send-otp / verify-otp / me; role provisioning on first login.
- Doctor: matching shifts, accept (swipe-to-accept for emergencies), my schedule +
  weekly availability editor, QR/manual check-in & check-out, earnings dashboard,
  editable profile with verification status, documents section, reliability score.
- Hospital: dashboard (Need-Doctor-Now hero, stats, monthly cost, open/filled/pending),
  Post a Requirement form, ranked doctor matches + Book (double-booking prevented),
  approve attendance → releases payment, hospital profile.
- Emergency "Need Doctor Now": broadcast form → notifies emergency-available verified
  doctors → broadcast confirmation → view matches / book.
- Automatic replacement: doctor cancel reopens duty + notifies up to 5 replacements.
- Admin: overview (totals + platform revenue), doctor verify/suspend/reinstate, all duties.
- Notifications center. Seed demo Hyderabad data (8 doctors, 2 hospitals, 6 duties).
- Verified via testing agent: backend 31/31, frontend 8/8 flows.

## Backlog
- **P1**: In-app messaging (hospital↔doctor after booking); push notifications (on request,
  needs build); real SMS OTP provider; document upload to object storage.
- **P1**: State guard on approve endpoint; implement decline endpoint semantics.
- **P2**: Availability-aware matching + real distance from device GPS; invoices/PDF;
  disputes; hospital registration/verification flow; analytics charts.
- **P3 (spec Phase 3)**: AI natural-language staffing request, demand forecasting,
  dynamic pricing, more professional types (nurses etc.), multi-city.

## Next Tasks
- Add in-app messaging thread per booked duty.
- Add document upload (Emergent Object Storage) to doctor verification.
- Hospital self-registration + admin hospital verification.
