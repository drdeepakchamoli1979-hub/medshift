# MedShift — Demo Test Credentials

Login is **Mobile OTP** (demo mode). After tapping **Send OTP**, the 6-digit code is
returned on-screen (dev_otp) and auto-filled — no SMS needed.

The app has **two roles only: Doctor and Hospital** (admin was removed from the app;
admin endpoints remain server-side only and are not reachable from the UI).

The Login screen has one-tap **Quick demo access** buttons (Doctor / Hospital)
that prefill the number, send the OTP, and auto-fill the code.

| Role     | Phone           | Notes |
|----------|-----------------|-------|
| Doctor   | +919000000001   | Dr. Arjun Reddy — Intensivist, VERIFIED, has earnings + a confirmed shift |
| Hospital | +919000000002   | Apollo Health City (Jubilee Hills) — open + emergency duties |
| Doctor 2 | +919000000003   | Dr. Priya Nair — Emergency Medicine, VERIFIED |

Any other 10-digit number creates a fresh account for the selected role
(**doctor or hospital only** — requesting `admin` returns HTTP 403).

## API (dev)
- Base: `EXPO_PUBLIC_BACKEND_URL` + `/api`
- `POST /api/auth/send-otp` `{ phone, role }` → returns `dev_otp` in demo mode (throttled: 1 / 20s per phone)
- `POST /api/auth/verify-otp` `{ phone, otp, role }` → returns `access_token` (JWT, 30d).
  New users may only self-assign `doctor` or `hospital`; `admin` is rejected (403).
- Bearer token stored in secure storage under key `medshift_token`.
- `GET /api/duty/{id}` is object-level authorized (owning hospital / assigned doctor / OPEN listing).
