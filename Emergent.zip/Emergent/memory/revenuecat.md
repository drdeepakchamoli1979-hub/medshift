# RevenueCat — setup-partial (2026-09-14)
Memory for interacting with the user's RevenueCat account via the integration proxy later.
Provisioning + SDK keys are DONE. The client paywall/gating is NOT yet wired into the app
(src/revenuecat.tsx exists but is unused). No secrets are stored in this file.

## Identifiers (from /setup response — copy verbatim)
- rc_project_id: projdbe439aa
- apple_app_id: appc953bf7c44
- play_app_id: app1f932a6eeb
- entitlement_lookup_key: pro
- offering_lookup_key: default
- Packages (package -> product_id, current price):
  - $rc_monthly -> prodff40913f86   ($9.99 / P1M, trial: none)
  - $rc_annual  -> prod6ae6205115   ($79.99 / P1Y, trial: none)
- Dashboard: https://app.revenuecat.com/projects/projdbe439aa
- SDK keys are written in frontend/.env (EXPO_PUBLIC_REVENUECAT_TEST/IOS/ANDROID_API_KEY).

## Status check
Status: `curl -sS -H "$AUTH" "$INTEGRATION_PROXY_URL/internal/revenuecat/projects/52299648-244a-46eb-974c-eae9a0d8f24c/status"`
(project_state was "connected"; if it ever drops below project_created, re-fetch the playbook via integration_expert.)

## Remaining app-side work (next step)
- Wire app/_layout.tsx: module-scope initializeRevenueCat() + wrap in SubscriptionProvider;
  bind identity via Purchases.logIn(user.id)/logOut() on every auth path.
- Build a coded paywall screen (app/paywall.tsx) using useSubscription (offerings/purchase/restore),
  with a Restore Purchases button; gate a Pro perk for doctors and hospitals on isSubscribed.
- Pro gating is CLIENT-SIDE ONLY (customerInfo.entitlements.active.pro). Do NOT add backend is_pro.

## Later product/price updates (integration proxy ONLY — never the RevenueCat REST API)
- Upsert price/duration/trial or add package:
  POST $INTEGRATION_PROXY_URL/internal/revenuecat/projects/52299648-244a-46eb-974c-eae9a0d8f24c/products
  body: {"products":[{"package":"$rc_monthly","price":14.99,"currency":"USD","period":"P1M","trial":"P1W","prices":[{"amount_micros":14990000,"currency":"USD"}]}]}
- Remove package:
  DELETE $INTEGRATION_PROXY_URL/internal/revenuecat/projects/52299648-244a-46eb-974c-eae9a0d8f24c/products/%24rc_monthly
- Recover identifiers / repopulate .env: re-run the idempotent /setup call.

## Going live (USER does these; needed only for real store purchases)
Upload App Store Connect API key (.p8) + Google Play service-account JSON to the RevenueCat
dashboard, set up payment profiles, and create matching IAP products with the SAME product IDs.
All steps are in the FAQ section of the payments panel.
